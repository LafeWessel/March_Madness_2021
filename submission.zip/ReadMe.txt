To run the submission.py file properly, you must place it in the directory that contains the
March Madness.xlsx Excel file.
When run, the script will look for the 2020 sheet of March Madness.xlsx, calculate the scores based on
our algorithm, then it will print the top 10 teams that we select.

If you have issues running the code, try installing the pandas and sklearn libraries.
To do this on Windows or Mac (probably), open a command prompt/terminal, and type
	pip install pandas scikit-learn
This should install the required packages and allow you to run the script.